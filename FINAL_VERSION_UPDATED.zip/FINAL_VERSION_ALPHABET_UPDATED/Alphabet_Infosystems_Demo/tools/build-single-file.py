"""Rebuild alphabet-infosystems-demo-single-file.html from the website/ folder.
Run from the project root:  python3 tools/build-single-file.py
Inlines style.css, script.js and every assets/ image (as data: addresses) and
recomputes the Content-Security-Policy hashes for the inline scripts."""
import base64, hashlib, mimetypes, pathlib, re

root = pathlib.Path(__file__).resolve().parent.parent
site = root / "website"
html = (site / "index.html").read_text(encoding="utf-8")
css = (site / "style.css").read_text(encoding="utf-8")
js = (site / "script.js").read_text(encoding="utf-8")

def data_uri(rel):
    p = site / rel
    mime = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    return "data:%s;base64,%s" % (mime, base64.b64encode(p.read_bytes()).decode())

# local images (not the absolute https:// social-preview addresses)
html = re.sub(r'(src|href)="(assets/[^"]+)"', lambda m: '%s="%s"' % (m.group(1), data_uri(m.group(2))), html)
html = html.replace('<link rel="stylesheet" href="style.css">', "<style>\n%s\n</style>" % css)
js = js.replace('href: "case-study-geetva.html"', 'href: "website/case-study-geetva.html"')
html = html.replace('<script src="script.js"></script>', "<script>\n%s\n</script>" % js)
html = html.replace('href="case-study-geetva.html"', 'href="website/case-study-geetva.html"')

# CSP: allow exactly the inline scripts that exist now
inline = re.findall(r"<script>(.*?)</script>", html, flags=re.S)
hashes = " ".join("'sha256-%s'" % base64.b64encode(hashlib.sha256(s.encode()).digest()).decode() for s in inline)
html = re.sub(r"script-src 'self' 'sha256-[^']+'", "script-src " + hashes, html, count=1)
html = html.replace("style-src 'self'", "style-src 'self' 'unsafe-inline'", 1)

out = root / "alphabet-infosystems-demo-single-file.html"
out.write_text(html, encoding="utf-8")
print("wrote", out.name, round(out.stat().st_size / 1024), "KB,", len(inline), "inline scripts hashed")
